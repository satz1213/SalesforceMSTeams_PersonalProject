/**
 * Pure pass-through relay between Bot Framework and TeamsBotMessagingResource.
 *
 * Why this exists: Salesforce's REST dispatcher intercepts any standard
 * "Authorization" header on a /services/apexrest/ request and tries to
 * validate it as a Salesforce session token, returning a platform-level 401
 * before Apex ever runs - even on a Guest Site. Bot Framework always sends
 * its JWT in exactly that header (non-negotiable, part of the Bot Connector
 * protocol), so Salesforce can never receive it directly. This function does
 * nothing except move that header to a name Salesforce doesn't intercept
 * (X-Bot-Framework-Authorization) and forward everything else unchanged.
 *
 * All real logic - JWT validation, card building, Case updates - stays in
 * TeamsBotMessagingResource.cls. This is plumbing only, on purpose: don't add
 * business logic here, or the two implementations will drift.
 */
const https = require('https');

const SALESFORCE_ENDPOINT = process.env.SALESFORCE_MESSAGING_ENDPOINT;

module.exports = async function (context, req) {
    if (!SALESFORCE_ENDPOINT) {
        context.log.error('SALESFORCE_MESSAGING_ENDPOINT app setting is not configured.');
        context.res = { status: 500 };
        return;
    }

    const authHeader = req.headers['authorization'] || '';
    const body = JSON.stringify(req.body || {});

    try {
        const salesforceResponse = await forward(body, authHeader);
        context.res = {
            status: salesforceResponse.statusCode,
            headers: { 'Content-Type': 'application/json' },
            body: salesforceResponse.body
        };
    } catch (err) {
        context.log.error('Failed to reach Salesforce endpoint:', err);
        context.res = { status: 502 };
    }
};

function forward(body, authHeader) {
    return new Promise((resolve, reject) => {
        const url = new URL(SALESFORCE_ENDPOINT);
        const options = {
            hostname: url.hostname,
            path: url.pathname + url.search,
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(body),
                'X-Bot-Framework-Authorization': authHeader
            }
        };

        const request = https.request(options, (response) => {
            let data = '';
            response.on('data', (chunk) => (data += chunk));
            response.on('end', () => resolve({ statusCode: response.statusCode, body: data }));
        });

        request.on('error', reject);
        request.write(body);
        request.end();
    });
}
